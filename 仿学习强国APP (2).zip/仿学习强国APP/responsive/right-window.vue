<template>
  <view class="right-window">
    <view class="right-content">
      <!-- 当 currentId 非 0 时加载详情组件 -->
      <news-detail v-if="currentId" :id="currentId" />
    </view>
  </view>
</template>

<script>
import NewsDetail from '@/pages/news/detail.vue';

export default {
  components: {
    NewsDetail
  },
  data() {
    return {
      currentId: 0
    };
  },
  mounted() {
    uni.$on('updateNewsDetail', (id) => {
      this.currentId = id;
      console.log("right-window 接收到新闻 ID:", id);
    });
  },
  beforeDestroy() {
    uni.$off('updateNewsDetail');
  }
};
</script>

<style>
/* 外层容器 */
.right-window {
  width: 417px; /* 原400px + 17px滚动条宽度 */
  height: 100vh;
  position: fixed;
  right: 0;
  top: 0;
  background: linear-gradient(to bottom, #fff 0%, #f9f3e9 100%);
  box-shadow: -2px 0 12px rgba(170, 0, 0, 0.15);
  z-index: 1000;
  border-left: 3px solid #aa0000;

  display: flex;
  flex-direction: column;
}

/* 可滚动内容区 */
.right-content {
  flex: 1; /* 让内容填充整个容器 */
  padding: 30rpx 40rpx 100rpx 50rpx;
  overflow-y: auto;
  pointer-events: auto; /* 确保允许点击 */
}

/* 自定义滚动条 */
.right-content::-webkit-scrollbar {
  width: 8px;
  background-color: #f5f5f5;
}

.right-content::-webkit-scrollbar-thumb {
  background: linear-gradient(45deg, #aa0000 30%, #d4af37 100%);
  border-radius: 4px;
}

.right-content::-webkit-scrollbar-track {
  background: #f9f3e9;
}

/* #ifdef H5 */
/* 标题栏增强样式 */
.title {
  font-size: 40rpx;
  color: #aa0000;
  padding: 20rpx 0;
  border-bottom: 2px solid #d4af37;
  margin-bottom: 30rpx;
  position: relative;
}
/* #endif */

/* 信息栏增强 */
.info {
  background: #fff5f5;
  padding: 20rpx;
  border-radius: 8rpx;
  margin-bottom: 30rpx;
  border-left: 4px solid #d4af37;

  .source {
    color: #aa0000;
    font-weight: bold;
  }

  .datetime {
    color: #d4af37;
    float: right;
  }
}

/* 会议新闻特殊样式 */
.meeting-content {
  .section-title {
    font-size: 34rpx;
    color: #aa0000;
    padding-left: 30rpx;
    position: relative;

    &::before {
      content: "";
      position: absolute;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
      width: 6px;
      height: 24rpx;
      background: #d4af37;
    }
  }

  .participants-list {
    background: #fff9f9;
    padding: 20rpx;
    border-radius: 8rpx;
    margin: 20rpx 0;

    li {
      line-height: 1.8;
      padding-left: 20rpx;
      position: relative;

      &::before {
        content: "•";
        color: #d4af37;
        position: absolute;
        left: 0;
      }
    }
  }
}
</style>

<!-- 可选：在宽屏下微调 right-window 的表现 -->
<style>
@media (min-width: 768px) {
  .right-window {
    /* 适配大屏幕 */
  }
}
</style>
