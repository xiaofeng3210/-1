<template>
    <view class="item" @click="click">
        <view class="top">
            <image class="image" :src="item.img_url" mode="aspectFill"></image>
            <view class="title-container">
                <!-- 标题 -->
                <view class="title">{{ item.title }}</view>
            </view>
        </view>
        <view class="info">
            <!-- 来源 -->
            <view class="source">{{ item.source }}</view>
            <!-- 评论数 -->
            <view class="comment">{{ item.comment_count }}</view>
            <!-- 日期或时间 -->
            <view class="datetime">{{ item.datetime }}</view>
        </view>
    </view>
</template>

<script>
export default {
    name: "news-item",
    props: {
        item: {
            type: Object,
            required: true
        }
    },
    methods: {
        click() {
            // 触发父组件的点击事件
            this.$emit("click");
        }
    }
};
</script>

<style scoped lang="scss">
.item {
    display: flex;
    flex-direction: column;
    margin-bottom: 30rpx;
    padding-bottom: 20rpx;
    border-bottom: 1rpx solid #eee;

    .top {
        display: flex;
        gap: 30rpx;
        align-items: center;

        .image {
            width: 260rpx;
            height: 200rpx;
            border-radius: 8rpx;
        }

        .title-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;

            .title {
                font-size: 28rpx;
                line-height: 1.4;
                color: #333; /* 标题颜色为深色 */
                margin-bottom: 10rpx;
            }

            .tag {
                display: inline-block;
                background-color: #aa0000;
                color: #fff;
                padding: 4rpx 10rpx;
                font-size: 20rpx;
                border-radius: 5rpx;
            }
        }
    }

    .info {
        display: flex;
        gap: 30rpx;
        margin-top: 20rpx;
        color: #666;
        font-size: 24rpx;
    }
}
</style>
