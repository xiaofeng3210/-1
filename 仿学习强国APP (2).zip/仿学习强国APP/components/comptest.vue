<template>
	<view>
		这是一个自定义组件的测试
		<view>这是父组件传过来的值：{{msg}}</view>
		<button type="primary" @click="sendMsg">给父组件传值</button>
	</view>
</template>

<script>
	export default{
		name:"comptest",
		data(){
			return{
				num:5
			};
		},
		props:['msg'],
		methods:{
			sendMsg(){
				this.$emit("myEven",this.num)
			}
		}
	}
	
</script>

<style>
</style>