<template>
  <view class="tabs">
    <scroll-view class="tabs-title" scroll-x="true">
      <view
        v-for="(item, index) in tabList"
        :key="index"
        :class="{ active: active === index }"
        @click="ontabtap(index)"
      >
        {{ item.name }}
      </view>
    </scroll-view>
  </view>
  <view class="newslist">
    <NewsItem
      v-for="(item, index) in news"
      :key="index"
      :item="item"
      @click="tapToDetail(item.id)"
    />
  </view>
</template>

<script>
import { friendlyDate } from "../../common/util.js";
import NewsItem from "../../components/NewsItem.vue"; // 引入自定义组件

export default {
  components: {
    NewsItem
  },
  data() {
    return {
      news: [], // 新闻数据
      tabList: [
        { id: "tabe1", name: "推荐", type: 1 },
        { id: "tabe2", name: "要闻", type: 2 },
        { id: "tabe3", name: "新思想", type: 3 },
        { id: "tabe4", name: "广东", type: 4 },
        { id: "tabe5", name: "综合", type: 5 },
        { id: "tabe6", name: "科技", type: 6 },
        { id: "tabe7", name: "军事", type: 7 },
        { id: "tabe8", name: "体育", type: 8 },
        { id: "tabe9", name: "文化", type: 9 },
        { id: "tab10", name: "旅游", type: 10 },
        { id: "tab11", name: "国际", type: 11 }
      ],
      active: 0 // 当前激活的 Tab 索引
    };
  },
  methods: {
    // 点击 Tab 时请求不同类别的新闻
    ontabtap(index) {
      this.active = index;
      this.requestNewsList(); // 重新请求新闻
    },
    // 点击新闻项，根据屏幕宽度判断是跳转还是通过事件通知右侧窗口加载详情
    tapToDetail(id) {
      const info = uni.getSystemInfoSync();
      console.log("当前屏幕宽度：", info.windowWidth);
      if (info.windowWidth > 768) {
        // 宽屏下通过事件通知右侧窗口加载详情
        uni.$emit("updateNewsDetail", id);
      } else {
        // 窄屏下使用页面跳转
        uni.navigateTo({
          url: `./detail?id=${id}`
        });
      }
    },
    // 发送请求获取新闻数据
    requestNewsList() {
      const selectedType = this.tabList[this.active].type; // 获取当前选中的新闻类别
      uni.request({
        url: "http://127.0.0.1:3000/news",
        method: "POST",
        header: { "Content-Type": "application/json" },
        data: { type: selectedType },
        success: (res) => {
          console.log("新闻数据：", res.data);
          if (!Array.isArray(res.data)) {
            console.error("数据格式错误", res.data);
            return;
          }
          this.news = res.data.map(item => ({
            ...item,
            datetime: friendlyDate(new Date(item.datetime))
          }));
        },
        fail: (err) => {
          console.error("请求失败:", err);
        }
      });
    }
  },
  onLoad() {
    this.requestNewsList(); // 页面首次加载时请求默认新闻
  }
};
</script>

<style lang="scss">
page {
  height: 100%;
}

.tabs {
  height: 120rpx;
  background-color: #fff;

  .tabs-title {
    height: 100%;
    white-space: nowrap;

    view {
      display: inline-block;
      width: 120rpx;
      height: 100rpx;
      line-height: 120rpx;
      color: #333;
      text-align: center;
      border-right: 1rpx solid #eee;
    }

    .active {
      background: #aa0000;
      color: #ffffff;
    }
  }
}

.newslist {
  display: flex;
  flex-direction: column;
  padding: 20rpx;
}

/* 新闻信息靠左对齐，间隔缩小 */
.info {
  display: flex;
  flex-direction: row;
  gap: 10rpx; /* 缩小间距 */
  margin-top: 10rpx;
  color: #666;
  font-size: 24rpx;
  align-items: center;
  justify-content: flex-start; /* 确保内容靠左 */
}
</style>

<!-- 新增宽屏适配样式，不改变原有样式 -->
<style lang="scss">
  @media (min-width: 768px) {
    .newslist {
      width: calc(100% - 420px);
      padding-right: 420px;
    }
  }
</style>
