<template>
  <view class="news-detail">
    <!-- 新闻封面图片 + 标题叠加 -->
    <view class="image-container" v-if="news.img_url">
      <image class="news-image" :src="news.img_url" mode="widthFix"></image>
      <view class="overlay">
        <text class="title">{{ news.title }}</text>
      </view>
    </view>

    <!-- 新闻信息（来源 + 时间） -->
    <view class="info">
      <text class="source">{{ news.source }}</text>
      <text class="datetime">{{ news.datetime }}</text>
    </view>

    <!-- 文章内容 -->
    <view class="content">{{ news.content }}</view>
  </view>
</template>

<script>
import { myRequest } from '../../common/api.js'; // 导入 myRequest 方法

export default {
  props: {
    // 当作为子组件时接收新闻 ID
    id: {
      type: [String, Number],
      default: 0
    }
  },
  data() {
    return {
      news: {} // 存储新闻详情
    };
  },
  watch: {
    // immediate: true 表示第一次赋值也会触发
    id: {
      immediate: true,
      handler(newVal) {
        console.log("detail.vue watch immediate: id =", newVal);
        if (newVal) {
          this.fetchNewsDetail(newVal);
        }
      }
    }
  },
  // onLoad 仅在页面跳转时触发，宽屏下作为子组件不调用 onLoad
  onLoad(options) {
    console.log("接收参数:", options);
    const id = options.id || this.id;
    if (id) {
      this.fetchNewsDetail(id);
    }
  },
  methods: {
    async fetchNewsDetail(newsId) {
      try {
        const res = await this.$myRequest({
          url: '/newsDetail',
          method: 'POST',
          data: { newsId }
        });
        console.log("新闻详情:", res);
        if (res.data.length > 0) {
          res.data[0].datetime = new Date(res.data[0].datetime).toLocaleDateString();
          this.news = res.data[0];

          // 设置页面标题为新闻标题
          uni.setNavigationBarTitle({
            title: this.news.title
          });
        }
      } catch (err) {
        console.error("请求新闻详情失败:", err);
      }
    }
  }
};
</script>

<style lang="scss">
.news-detail {
    padding: 20rpx;
    background: #fff;
}

/* 图片+标题 */
.image-container {
    position: relative;
    width: 100%;
}
.news-image {
    width: 100%;
    border-radius: 10rpx;
}
.overlay {
    position: absolute;
    bottom: 10rpx;
    left: 0;
    width: 95%;
    padding: 20rpx;
    background: rgba(0, 0, 0, 0); /* 半透明背景，增强可读性 */
    text-align: center;
}

/* 标题样式，颜色受 H5 影响 */
.title {
    font-size: 30rpx;
    font-weight: bold;
    color: #fff; /* 默认白色，确保标题在图片上清晰 */
    
    /* #ifdef H5 */
    color: #fff; /* H5平台时，标题颜色为蓝色 */
    /* #endif */

    /* #ifndef H5 */
    color: red; /* 非 H5 平台时，标题颜色为红色 */
    /* #endif */
}

/* 新闻信息 */
.info {
    display: flex;
    justify-content: space-between;
    color: #999;
    font-size: 24rpx;
    padding: 0 10rpx;
    margin-bottom: 20rpx;
}

/* 文章内容 */
.content {
    font-size: 28rpx;
    line-height: 1.6;
    text-align: justify;
    padding: 0 10rpx;
}
</style>

<!-- 新增宽屏适配样式，不改变原有样式 -->
<style lang="scss">
  @media (min-width: 768px) {
    .news-detail {
      max-width: 750rpx;
      margin: 0 auto;
      padding: 30rpx;
    }
    .news-detail .title {
      font-size: 40rpx;
      margin-bottom: 40rpx;
    }
    .news-detail .content {
      font-size: 30rpx;
      line-height: 1.9;
    }
  }
</style>
