<template>
	<view>
		<uni-easyinput v-model="item.name" placeholder="请输入姓名"/>
		<uni-easyinput v-model="item.name" placeholder="请输入电话号码"/>
		<button type="primary" @click="add">提交</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				item: {
					name:"",
					phone:""
				}
			}
		},
		methods: {
			add() {
				const db = UniCloud.database();
				db.collection('contact').add(this.item).then(res => {
					console.log(res)
					uni.navigateBack({
						delta:1,
					})
				})
			}
		}
	}
</script>

<style>

</style>
