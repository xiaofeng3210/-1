<template>
	<view>
		<unicloud-db ref="udb" v-slot:default="{data, loading, error, options}" collection="contacts">
			<view v-if="error">{{error.message}}</view>
			<view v-else>
				<uni-list>
					<uni-list-item v-for="(item,index) in data" :key="item.id" :title="item.name" :note="item.phone"
						@longpress="rmItem(item._id)" @click="updateItem(item)" link></uni-list-item>
				</uni-list>
			</view>
		</unicloud-db>
		<uni-icons type="personadd" size="50rpx" style="float:right" @click="addItem"></uni-icons>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			addItem() {
				uni.navigateTo({
					url:"./addcontact" 
				})
			},
			updateItem(item){
				uni.navigateTo({
					url:"./updatecontact?item=" + JSON.stringify(item)
				})
			},
			rmItem(id) {
				this.$refs.udb.remove(id)
			}
		}
	}
</script>

<style>

</style>
