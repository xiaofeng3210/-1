<template>
	<view>
		<comptest :msg="pmsg" @myEven="getMsg"></comptest>
		<view>子组件传递过来的值：{{num}}</view>
		<test-a></test-a>
		<test-b></test-b>
	</view>
</template>

<script>
	import comptest from "../../components/comptest.vue";
	import testa from "../../components/a.vue";
	import testb from "../../components/b.vue";
	export default {
		data() {
			return {
				pmsg:"hello",
				num:0
			}
		},
		methods: {
			getMsg(res){
				console.log(res)
				this.num=res
			}
		},
		components:{
			comptest,
			'test-a':testa,
			'test-b':testb
		}
	}
</script>

<style>

</style>
// url: "http://10.0.2.2:3000/news",