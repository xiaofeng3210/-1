<template>
	<view>
		<uni-easyinput v-model="item.name" placeholder="请输入姓名"/>
		<uni-easyinput v-model="item.name" placeholder="请输入电话号码"/>
		<button type="primary" @click="update">修改</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				item: {
					_id: "", name:"", phone:""
				},
			}
		},
		methods: {
			update() {
				const db = uniCloud.database();
				let item = {
					...this.item 
				}
				delete item._id
				db.collection('contacts').doc(this.item._id).update(item).then(res => {
					uni.navigateBack({
						delta:1
					})
				})   }
		},
		onLoad({item}) {
			this.item = JSON.parse(item)
		}
	}
</script>

<style>

</style>
