<template>
  <view class="page">
    <!-- 顶部提示文字 -->
    <view class="intro-text">
      <text>为了中华民族的伟大复兴，我们要不断地提高自己，不断地塑造自己，为中华的未来出谋划策。请添加“强国”话题吧！</text>
    </view>

    <!-- 添加话题表单，白色卡片区域 -->
    <uni-section title="添加话题" class="form-section">
      <uni-forms ref="topicForm" :model="formData" :rules="rules">
        <!-- 话题标题 -->
        <uni-forms-item label="话题" name="title" required>
          <uni-easyinput
            v-model="formData.title"
            placeholder="请输入话题"
          />
        </uni-forms-item>

        <!-- 话题内容，带清空图标 -->
        <uni-forms-item label="话题内容" name="content" required>
          <view class="textarea-with-clear">
            <uni-easyinput
              type="textarea"
              v-model="formData.content"
              placeholder="请输入话题内容"
            />
            <text
              v-if="formData.content"
              class="clear-icon"
              @click="formData.content = ''"
            >×</text>
          </view>
        </uni-forms-item>

        <!-- 提交按钮 -->
        <view class="btn-container">
          <button type="primary" @click="submitForm">提交</button>
        </view>
      </uni-forms>
    </uni-section>
  </view>
</template>

<script>
export default {
  data() {
    return {
      formData: {
        title: '',
        content: ''
      },
      rules: {
        title: { required: true, errorMessage: '请输入话题' },
        content: { required: true, errorMessage: '请输入话题内容' }
      }
    };
  },
  methods: {
    submitForm() {
      this.$refs.topicForm
        .validate()
        .then(valid => {
          if (valid) {
            // 验证通过，调用后端 API 保存到数据库
            uni.request({
              url: 'http://127.0.0.1:3000/', // 后端接口地址
              method: 'POST',
              data: {
                title: this.formData.title,
                content: this.formData.content
              },
              success: (res) => {
                if (res.data.code === 0) {
                  // 保存成功
                  uni.showToast({ title: '提交成功' });
                  // 根据需要，可重置表单
                  this.formData.title = '';
                  this.formData.content = '';
                } else {
                  // 保存失败
                  uni.showToast({ icon: 'none', title: '提交失败' });
                }
              },
              fail: (err) => {
                console.error('请求失败：', err);
                uni.showToast({ icon: 'none', title: '请求失败' });
              }
            });
          }
        })
        .catch(err => {
          console.error('表单验证失败：', err);
        });
    }
  }
};
</script>

<style scoped>
.page {
  min-height: 100vh;
  width: 100%;
  background-color: #f8f8f8;
  display: flex;
  flex-direction: column;
}

.intro-text {
  background-color: #ffffff;
  padding: 12px 16px;
  margin-bottom: 10px;
  line-height: 1.6;
  font-size: 14px;
  color: #333;
  text-indent: 2em;
}

.form-section {
  flex: 1;
  background-color: #ffffff;
  padding: 16px;
}

uni-forms-item {
  margin-bottom: 10px;
}

.btn-container {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}

button {
  width: 100%;
  padding: 2px 0;
  background-color: #007aff;
  color: #fff;
  border: none;
  border-radius: 3px;
  font-size: 14px;
}

/* 输入框和清空图标相对定位 */
.textarea-with-clear {
  position: relative;
}

.clear-icon {
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 18px;
  color: #999;
  background-color: rgba(240, 240, 240, 0.9);
  border-radius: 50%;
  width: 20px;
  height: 20px;
  line-height: 20px;
  text-align: center;
  z-index: 10;
  cursor: pointer;
}
</style>
