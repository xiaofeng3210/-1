<template>
  <view>
    <uni-card :is-shadow="true" is-full="true">
      <text class="uni-h6" space="emsp">
        {{ '为了中华民族的伟大复兴，我们要不断锤炼自己，不断探索自我的无限潜能。' }}
      </text>
    </uni-card>

    <uni-section title="添加话题" type="line" padding="0 25px">
      <view class="example">
        <uni-forms
          ref="form"
          :rules="rules"
          :modelValue="topicData"
          label-width="80px"
        >
          <!-- 图片选择 -->
          <uni-forms-item label="选择图片" name="imgs" required>
            <uni-file-picker
              v-model="topicData.imgs"
              limit="3"
              file-mediatype="image"
              title=""
              auto-upload="false"
              @select="handleSelect"
              @delete="deleteImage"
            />
          </uni-forms-item>

          <!-- 话题标题 -->
          <uni-forms-item label="话题" name="title" required>
            <uni-easyinput
              v-model="topicData.title"
              placeholder="请输入话题"
            />
          </uni-forms-item>

          <!-- 话题内容 -->
          <uni-forms-item label="话题内容" name="content" required>
            <uni-easyinput
              type="textarea"
              v-model="topicData.content"
              placeholder="请输入话题内容"
            />
          </uni-forms-item>

          <button type="primary" @click="submit('form')">提交</button>
        </uni-forms>
      </view>
    </uni-section>
  </view>
</template>

<script>
export default {
  data() {
    return {
      topicData: {
        imgs: [],    // 存放 { extname, fileType, image, path, name, size, fileID, url }
        title: '',
        content: '',
      },
      rules: {
        imgs: {
          rules: [
            { required: true, errorMessage: '请至少选择一张图片' }
          ]
        },
        title: {
          rules: [
            { required: true, errorMessage: '话题不能为空' }
          ]
        },
        content: {
          rules: [
            { required: true, errorMessage: '话题内容不能为空' }
          ]
        }
      }
    };
  },
  methods: {
    // 选中文件后：先建立可预览的本地对象阵列，再异步上传并填充 fileID
    async handleSelect(e) {
      // 1. 构造临时文件数据，用 path 做预览，用 fileID 字段后续填充
      this.topicData.imgs = e.tempFiles.map(file => ({
        extname: file.extname,
        fileType: file.fileType,
        image: file.image,   // { width, height }
        path: file.path,     // 小程序本地预览路径
        size: file.size,
        name: file.name,
        fileID: '',          // 上传后再填
        url: file.path      // 先用本地 path 做预览
      }));

      // 2. 异步上传，上传完成后只更新 fileID（可选替换 url）
      for (let i = 0; i < e.tempFiles.length; i++) {
        try {
          const uploadRes = await uniCloud.uploadFile({
            cloudPath: `images/${Date.now()}_${e.tempFiles[i].name}`,
            filePath: e.tempFiles[i].path
          });
          // 填充云端 fileID
          this.topicData.imgs[i].fileID = uploadRes.fileID;
          // 如果想预览云端地址，把下面这一行注释打开：
          // this.topicData.imgs[i].url = uploadRes.fileID;
        } catch (err) {
          console.error('上传第 ' + i + ' 张图失败：', err);
        }
      }

      console.log('handleSelect 完成，当前 imgs：', this.topicData.imgs);
    },

    // 删除某张图片：如果已上传过，则先删除云端，再移除本地数组
    async deleteImage(e) {
      const idx = e.index;
      const item = this.topicData.imgs[idx];
      try {
        if (item.fileID) {
          await uniCloud.deleteFile({ fileList: [item.fileID] });
        }
      } catch (err) {
        console.warn('云端删除失败：', err);
      }
      this.topicData.imgs.splice(idx, 1);
    },

    // 提交到后端
    async addTopic() {
      try {
        const res = await this.$myRequest({
          url: '/addtopic',
          method: 'POST',
          data: this.topicData
        });
        console.log('服务器返回：', res);
      } catch (err) {
        console.error('提交话题失败：', err);
      }
    },

    // 表单校验并提交
    submit(ref) {
      this.$refs[ref]
        .validate()
        .then(validData => {
          // validData 中包含了 imgs/title/content
          this.topicData = validData;
          this.addTopic();
        })
        .catch(err => {
          console.warn('校验未通过：', err);
        });
    }
  }
};
</script>

<style scoped>
.example {
  padding: 20px;
}
/* 如需定制更多样式，可在这里添加 */
</style>
