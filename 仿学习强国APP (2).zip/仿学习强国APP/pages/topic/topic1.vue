<template>
  <view class="page">
    <!-- 顶部提示 -->
    <view class="intro-text">
      <text>为了中华民族的伟大复兴，我们要不断地提高自己，不断地塑造自己，为中华的未来出谋划策。请添加“强国”话题吧！</text>
    </view>

    <!-- 表单区域 -->
    <uni-section title="添加话题" class="form-section">
      <uni-forms ref="topicForm" :model="formData" :rules="rules">
        <!-- 话题标题 -->
        <uni-forms-item label="话题" name="title" required>
          <uni-easyinput
            v-model="formData.title"
            placeholder="请输入话题"
          />
        </uni-forms-item>

        <!-- 话题内容 -->
        <uni-forms-item label="话题内容" name="content" required>
          <view class="textarea-with-clear">
            <uni-easyinput
              type="textarea"
              v-model="formData.content"
              placeholder="请输入话题内容"
            />
            <text
              v-if="formData.content"
              class="clear-icon"
              @click="formData.content = ''"
            >×</text>
          </view>
        </uni-forms-item>

        <!-- 提交按钮 -->
        <view class="btn-container">
          <button type="primary" @click="submitForm">提交</button>
        </view>
      </uni-forms>
    </uni-section>
  </view>
</template>

<script>
export default {
  data() {
    return {
      formData: {
        title: '',
        content: ''
      },
      rules: {
        title: { required: true, errorMessage: '请输入话题' },
        content: { required: true, errorMessage: '请输入话题内容' }
      }
    };
  },
  methods: {
    submitForm() {
      this.$refs.topicForm.validate().then(valid => {
        if (valid) {
          // 发起请求
          uni.request({
            url: 'http://127.0.0.1:3000/api/topic/save',
            method: 'POST',
            data: {
              title: this.formData.title,
              content: this.formData.content
            },
            success: (res) => {
              console.log("返回结果：", res);
              if (res.data.code === 0) {
                uni.showToast({ title: '提交成功' });
                this.formData.title = '';
                this.formData.content = '';
              } else {
                uni.showToast({ icon: 'none', title: '提交失败' });
              }
            },
            fail: (err) => {
              console.error("请求失败：", err);
              uni.showToast({ icon: 'none', title: '请求失败' });
            }
          });
        }
      }).catch(err => {
        console.error('表单验证失败：', err);
      });
    }
  }
};
</script>

<style scoped>
.page {
  min-height: 100vh;
  background-color: #f8f8f8;
  padding: 10px;
}
.intro-text {
  background-color: #fff;
  padding: 12px 16px;
  margin-bottom: 10px;
  font-size: 14px;
  line-height: 1.6;
  color: #333;
  text-indent: 2em;
}
.form-section {
  background-color: #fff;
  padding: 16px;
}
.btn-container {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}
button {
 width: 100%;
 padding: 2px 0;
 background-color: #007aff;
 color: #fff;
 border: none;
 border-radius: 3px;
 font-size: 14px;
}
.textarea-with-clear {
  position: relative;
}
.clear-icon {
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 18px;
  color: #999;
  background: rgba(240, 240, 240, 0.9);
  border-radius: 50%;
  width: 20px;
  height: 20px;
  line-height: 20px;
  text-align: center;
  cursor: pointer;
}
</style>
