<template>
  <view class="topic-list">
    <view
      class="topic-item"
      v-for="topic in topics"
      :key="topic.id"
    >
      <!-- 标题（自动换行） -->
      <view class="topic-title">{{ topic.title }}</view>

      <!-- 图片区域 -->
      <view class="image-container">
        <swiper
          v-if="(topic.imgs || []).length > 1"
          class="topic-swiper"
          indicator-dots
        >
          <swiper-item
            v-for="(img, i) in topic.imgs"
            :key="i"
          >
            <image
              :src="img.url"
              mode="aspectFill"
              class="topic-img"
            />
          </swiper-item>
        </swiper>
        <image
          v-else-if="(topic.imgs || []).length === 1"
          :src="topic.imgs[0].url"
          mode="aspectFill"
          class="topic-img"
        />
        <view v-else class="no-image">暂无图片</view>
      </view>

      <!-- 操作按钮：带内置图标 -->
      <view class="topic-actions">
        <view class="action-item">
          <uni-icons type="redo" size="18" color="#666" />
          <text class="action-text">分享</text>
        </view>
        <view class="action-item">
          <uni-icons type="heart" size="18" color="#666" />
          <text class="action-text">点赞</text>
        </view>
        <view class="action-item">
          <uni-icons type="chatboxes" size="18" color="#666" />
          <text class="action-text">评论</text>
        </view>
      </view>
    </view>

    <!-- 右下角悬浮加号按钮 -->
    <view class="fab" @click="goToAdd">
      <text class="fab-icon">＋</text>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      topics: []
    };
  },
  onLoad() {
    this.getTopics();
  },
  methods: {
    async getTopics() {
      try {
        const resp = await this.$myRequest({
          url: '/topics',
          method: 'GET'
        });
  
        console.log('获取话题列表返回数据：', resp);
  
        const payload = resp.data;
   
        if (payload.code === 0) {
          this.topics = payload.data;
  
        } else {
          console.warn('获取话题失败，服务端返回错误：', payload.message);
        }
      } catch (err) {
        console.error('获取话题列表失败：', err);
      }
    },
    goToAdd() {
      uni.navigateTo({
        url: '/pages/topic/addtopic'
      });
    }
  }
};
</script>

<style scoped>
.topic-list {
  padding: 10px;
  background: #f5f5f5;
  padding-bottom: 80px;
}
.topic-item {
  margin-bottom: 15px;
  background: #fff;
  border-radius: 6px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
.topic-title {
  display: block;
  font-size: 16px;
  color: #333;
  padding: 12px;
  white-space: normal;
  word-break: break-word;
  line-height: 1.5;
}
.image-container {
  width: 100%;
  height: 200px;
  background: #eee;
}
.topic-swiper,
.topic-img {
  width: 100%;
  height: 100%;
}
.no-image {
  width: 100%;
  height: 100%;
  line-height: 200px;
  text-align: center;
  color: #999;
}
/* 操作栏 */
.topic-actions {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  align-items: center;
  padding: 10px 0;
  border-top: 1px solid #eee;
}
.action-item {
  display: flex;
  align-items: center;
  font-size: 14px;
  color: #666;
}
.action-text {
  margin-left: 4px;
  font-size: 14px;
  color: #666;
}
/* 浮动按钮 */
.fab {
  position: fixed;
  right: 20px;
  bottom: 100px;
  width: 56px;
  height: 56px;
  background-color: #aa0000;
  border-radius: 28px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
  justify-content: center;
  align-items: center;
  display: flex;
  z-index: 1000;
}
.fab-icon {
  font-size: 32px;
  color: #fff;
  line-height: 56px;
  text-align: center;
}
</style>
