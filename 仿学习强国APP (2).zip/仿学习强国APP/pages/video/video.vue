<template>
  <view>
    <!-- 分类导航 -->
    <view class="tabs">
      <scroll-view class="tabs-title" scroll-x="true">
        <view
          v-for="(item, index) in tabList"
          :key="index"
          :class="{ active: active === index }"
          @click="onTabTap(index)"
        >
          {{ item.name }}
        </view>
      </scroll-view>
    </view>

    <!-- 视频列表 -->
    <view
      v-for="video in videos"
      :key="video.id"
      class="video-item"
      @click="tapToDetail(video.id)"
    >
      <!-- 视频播放器 -->
      <video
        :src="video.video_url"
        :poster="video.img_url"
        controls
        class="video-player"
      ></video>

      <!-- 视频标题 -->
      <view class="video-title">{{ video.title }}</view>

      <!-- 来源 + 点赞 + 分享 -->
      <view class="source-like-container">
        <view class="source">来源：{{ video.source }}</view>

        <view class="action-container">
          <!-- 点赞 -->
          <view class="like-section" @click.stop="toggleLike(video)">
            <image
              :src="video.likestatus ? likeIconActive : likeIconInactive"
              class="like-icon"
            ></image>
            <text class="like-count">{{ video.like_count }}</text>
          </view>

          <!-- 分享 -->
          <view class="share-section" @click.stop="shareVideo(video)">
            <image :src="shareIcon" class="share-icon"></image>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      tabList: [
        { id: "tab1", name: "推荐", type: 0 },
        { id: "tab2", name: "要闻", type: 1 },
        { id: "tab3", name: "新思想", type: 2 },
        { id: "tab4", name: "广东", type: 3 },
        { id: "tab5", name: "综合", type: 4 },
        { id: "tab6", name: "科技", type: 5 },
        { id: "tab7", name: "军事", type: 6 },
        { id: "tab8", name: "体育", type: 7 },
        { id: "tab9", name: "文化", type: 8 },
        { id: "tab10", name: "旅游", type: 9 },
        { id: "tab11", name: "国际", type: 10 }
      ],
      active: 0,
      videos: [],
      likeIconActive: "https://mp-3d9f043a-ac0b-4bfa-a852-70d8d84dc534.cdn.bspapp.com/点赞1.png",
      likeIconInactive: "https://mp-3d9f043a-ac0b-4bfa-a852-70d8d84dc534.cdn.bspapp.com/点赞2.png",
      shareIcon: "https://mp-3d9f043a-ac0b-4bfa-a852-70d8d84dc534.cdn.bspapp.com/分享.png"
    };
  },
  methods: {
    async requestVideoList() {
      try {
        const res = await this.$myRequest({
          url: "/video",
          method: "POST",
          data: {
            type: this.tabList[this.active].type
          }
        });
        this.videos = res.data;
      } catch (error) {
        console.error("获取视频失败:", error);
      }
    },

    onTabTap(index) {
      this.active = index;
      this.requestVideoList();
    },

    toggleLike(video) {
      video.likestatus = !video.likestatus;
      video.like_count += video.likestatus ? 1 : -1;
    },

    shareVideo(video) {
      uni.showShareMenu({
        withShareTicket: true,
        menus: ["shareAppMessage", "shareTimeline"],
        success() {
          console.log(`分享视频: ${video.title}`);
        },
        fail(err) {
          console.error("分享失败:", err);
        }
      });
    },

    tapToDetail(id) {
      uni.navigateTo({
        url: './videodetail?id=' + id + '&type=' + this.active
      });
    }
  },
  onLoad() {
    this.requestVideoList();
  }
};
</script>

<style lang="scss">
.tabs {
  height: 100rpx;
  background-color: #fff;

  .tabs-title {
    height: 100%;
    white-space: nowrap;

    view {
      display: inline-block;
      width: 120rpx;
      height: 100rpx;
      line-height: 100rpx;
      color: #333;
      text-align: center;
      border-right: 1rpx solid #eee;
    }

    .active {
      background: #aa0000;
      color: #ffffff;
    }
  }
}

.video-item {
  margin-bottom: 20px;
  padding: 10px;
  border-bottom: 1px solid #ddd;
}

.video-player {
  width: 100%;
  height: 200px;
  background-color: black;
}

.video-title {
  font-size: 16px;
  font-weight: bold;
  margin-top: 5px;
  color: #333;
}

.source-like-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 5px;
}

.source {
  font-size: 14px;
  color: #666;
}

.action-container {
  display: flex;
  align-items: center;
}

.like-section {
  display: flex;
  align-items: center;
  cursor: pointer;
  margin-right: 15px;
}

.like-icon {
  width: 24px;
  height: 24px;
  margin-right: 5px;
}

.like-count {
  font-size: 14px;
  color: #333;
}

.share-section {
  display: flex;
  align-items: center;
  cursor: pointer;
}

.share-icon {
  width: 24px;
  height: 24px;
}
</style>
