<template>
  <view class="videodetail">
    <swiper
      indicator-dots
      vertical
      :current="cur"
      duration="1000"
      @change="onSwiperChange"
    >
      <swiper-item v-for="(item, index) in videos" :key="index">
        <video
          :src="item.video_url"
          :id="'video-' + index"
          controls
          loop
          @click="onVideoClick"
        ></video>

        <view class="videoleft">
          <view class="author">{{ item.source }}</view>
          <view class="title">{{ item.title }}</view>
        </view>

        <view class="videoright">
          <!-- 点赞 -->
          <view class="like-container" @click.stop="changeLike(item.id)">
            <image
              class="like-icon"
              :src="item.likestatus ? likeIconActive : likeIconInactive"
            />
            <text class="like-count">{{ item.like_count }}</text>
          </view>

          <!-- 分享按钮（微信支持） -->
          <button open-type="share" class="share-button" @click.stop>
            <image class="share-icon" :src="shareIcon" />
            <text class="share-label">分享</text>
          </button>
        </view>
      </swiper-item>
    </swiper>
  </view>
</template>

<script>
export default {
  data() {
    return {
      videos: [],
      type: 0,
      videoid: "",
      cur: 0,
      play: false,
      likeIconActive:
        "https://mp-3d9f043a-ac0b-4bfa-a852-70d8d84dc534.cdn.bspapp.com/点赞4.png",
      likeIconInactive:
        "https://mp-3d9f043a-ac0b-4bfa-a852-70d8d84dc534.cdn.bspapp.com/点赞3.png",
      shareIcon:
        "https://mp-3d9f043a-ac0b-4bfa-a852-70d8d84dc534.cdn.bspapp.com/分享1.png"
    };
  },
  methods: {
    async requestVideoList() {
      const res = await this.$myRequest({
        url: "/video",
        method: "POST",
        data: { type: this.type }
      });

      res.data.forEach((item, i) => {
        if (item.id == this.videoid) this.cur = i;
      });

      this.videos = res.data;
    },

    onSwiperChange(e) {
      this.cur = e.detail.current;
      this.pauseAllVideos();
      this.playVideoByIdFromStart("video-" + this.cur);
    },

    onVideoClick(e) {
      const id = e.target.id;
      this.play ? this.onVideoPause(id) : this.onVideoPlay(id);
    },

    onVideoPlay(videoCptId) {
      this.pauseOtherVideos(videoCptId);
      this.playVideoById(videoCptId);
      this.play = true;
    },

    onVideoPause(videoCptId) {
      this.pauseVideoById(videoCptId);
      this.play = false;
    },

    pauseAllVideos() {
      this.videos.forEach((_, index) => {
        this.pauseVideoById(`video-${index}`);
      });
    },

    pauseOtherVideos(currentVideoCptId) {
      this.videos.forEach((_, index) => {
        const id = `video-${index}`;
        if (id !== currentVideoCptId) this.pauseVideoById(id);
      });
    },

    playVideoById(videoCptId) {
      uni.createVideoContext(videoCptId).play();
    },

    playVideoByIdFromStart(videoCptId) {
      const ctx = uni.createVideoContext(videoCptId);
      ctx.seek(0);
      ctx.play();
    },

    pauseVideoById(videoCptId) {
      uni.createVideoContext(videoCptId).pause();
    },

    async changeLike(id) {
      const video = this.videos[this.cur];
      if (video.likestatus === 0) {
        video.likestatus = 1;
        video.like_count++;
      } else {
        video.likestatus = 0;
        video.like_count--;
      }
      await this.updateVideo(id);
    },

    async updateVideo(id) {
      await this.$myRequest({
        url: "/updatevideo",
        method: "POST",
        data: {
          id: id,
          likestatus: this.videos[this.cur].likestatus,
          like_count: this.videos[this.cur].like_count
        }
      });
    }
  },

  onLoad(options) {
    this.videoid = options.id;
    this.type = options.type;
    this.requestVideoList();
  },

  // 微信分享配置
  onShareAppMessage() {
    const video = this.videos[this.cur];
    return {
      title: video.title,
      path: `/pages/video/videodetail?id=${video.id}&type=${this.type}`,
      imageUrl: video.cover || ""
    };
  },

  onShareTimeline() {
    const video = this.videos[this.cur];
    return {
      title: video.title,
      path: `/pages/video/videodetail?id=${video.id}&type=${this.type}`,
      imageUrl: video.cover || ""
    };
  }
};
</script>

<style lang="scss">
.videodetail {
  width: 100%;
  height: 100vh;
  background-color: #000;

  swiper {
    width: 100%;
    height: 100%;

    swiper-item {
      position: relative;

      video {
        width: 100%;
        height: 100%;
        background-color: #000;
      }

      .videoleft {
        z-index: 20;
        position: absolute;
        bottom: 20px;
        left: 10px;
        color: #fff;
        width: 150px;

        .author {
          height: 35px;
          line-height: 35px;
          font-size: 15px;
        }

        .title {
          line-height: 22px;
          font-size: 12px;
          word-wrap: break-word;
        }
      }

      .videoright {
        z-index: 20;
        position: absolute;
        bottom: 180px;
        right: 15px;
        display: flex;
        flex-direction: column;
        align-items: center;

        .like-container,
        .share-button {
          display: flex;
          flex-direction: column;
          align-items: center;
          margin-bottom: 20px;
          background: transparent;
          border: none;
          padding: 0;
        }

        .like-icon,
        .share-icon {
          width: 40px;
          height: 40px;
        }

        .like-count,
        .share-label {
          font-size: 14px;
          color: white;
          margin-top: 5px;
        }
      }
    }
  }
}
</style>
