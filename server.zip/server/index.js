const express = require("express");
const bodyParser = require("body-parser");
const mysql = require("mysql2/promise");
const app = express();

// 中间件
app.use(bodyParser.json());

// CORS 允许跨域请求
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  next();
});

// 数据库配置
const dbConfig = {
  host: "localhost",
  user: "root",
  password: "123456",
  database: "learndata"
};

// 创建连接池
const pool = mysql.createPool(dbConfig);

// 通用数据库错误处理
const handleDatabaseError = (res, err) => {
  console.error("数据库错误:", err.message);
  res.status(500).json({ error: "数据库发生错误" });
};

// 获取所有新闻（GET 请求）
app.get('/news', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM news ORDER BY datetime DESC');
    res.json(rows);
  } catch (err) {
    handleDatabaseError(res, err);
  }
});

// 根据新闻类型获取新闻（POST 请求）
app.post("/news", async (req, res) => {
  console.log("收到 POST /news 请求，参数：", req.body);

  if (!req.body || req.body.type === undefined) {
    return res.status(400).json({ error: "缺少 'type' 参数" });
  }

  const type = req.body.type;
  const sql = "SELECT * FROM news WHERE article_type = ? ORDER BY datetime DESC";

  try {
    const [rows] = await pool.execute(sql, [type]);
    res.json(rows);
  } catch (err) {
    handleDatabaseError(res, err);
  }
});

// 新闻详情接口
app.post("/newsDetail", async (req, res) => {
  console.log("收到 POST /newsDetail 请求，参数：", req.body);

  if (!req.body || !req.body.newsId) {
    return res.status(400).json({ error: "缺少 'newsId' 参数" });
  }

  const id = req.body.newsId;
  const sql = "SELECT * FROM news WHERE id = ?";

  try {
    const [rows] = await pool.execute(sql, [id]);
    res.json(rows);
  } catch (err) {
    handleDatabaseError(res, err);
  }
});

// 视频接口
app.post("/video", async (req, res) => {
  console.log("收到 POST /video 请求，参数：", req.body);

  if (!req.body || req.body.type === undefined) {
    return res.status(400).json({ error: "缺少 'type' 参数" });
  }

  const type = req.body.type;
  const sql = "SELECT * FROM video WHERE video_type = ? ORDER BY datetime DESC";

  try {
    const [rows] = await pool.execute(sql, [type]);
    res.json(rows);
  } catch (err) {
    handleDatabaseError(res, err);
  }
});

// 视频点赞更新接口
app.post("/updatevideo", async (req, res) => {
  const { id, likestatus, like_count } = req.body;

  if (!id || likestatus === undefined || like_count === undefined) {
    return res.status(400).json({ error: "缺少必要参数" });
  }

  const sql = "UPDATE video SET likestatus = ?, like_count = ? WHERE id = ?";

  try {
    const [rows] = await pool.execute(sql, [likestatus, like_count, id]);
    res.json(rows);
  } catch (err) {
    handleDatabaseError(res, err);
  }
});

// 添加话题接口
app.post("/api/topic/save", async (req, res) => {
  console.log("收到 POST /api/topic/save 请求，参数：", req.body);

  const { title, content } = req.body;

  if (!title || !content) {
    return res.status(400).json({ error: "缺少必要参数" });
  }

  const sql = "INSERT INTO topic (title, content) VALUES (?, ?)";

  try {
    const [result] = await pool.execute(sql, [title, content]);
    res.json({
      code: 0,
      message: "插入成功",
      data: {
        insertId: result.insertId
      }
    });
  } catch (err) {
    handleDatabaseError(res, err);
  }
});

// 添加话题接口（包含图片 fileID 数组）
app.post('/addtopic', async (req, res) => {
  console.log("收到 POST /addtopic 请求，参数：", req.body);

  const { title, content, imgs } = req.body;
  if (!title || !content || !Array.isArray(imgs)) {
    return res.status(400).json({ error: '缺少必要参数或 imgs 不是数组' });
  }

  // 将 imgs 数组序列化成 JSON 字符串存入数据库
  const imgsStr = JSON.stringify(imgs);
  // 假设 topic 表的 id 字段是自增的，这里不显式插 id
  const sql = 'INSERT INTO topic (title, content, imgs) VALUES (?, ?, ?)';

  try {
    const [result] = await pool.execute(sql, [title, content, imgsStr]);
    // 返回插入记录的 insertId
    res.json({
      code: 0,
      message: '插入成功',
      data: { insertId: result.insertId }
    });
  } catch (err) {
    handleDatabaseError(res, err);
  }
});

app.get('/topics', async (req, res) => {
  try {
    // 如果 imgs 是 NULL，就替换成 '[]'
    const [rows] = await pool.execute(`
      SELECT 
        id, 
        title, 
        content, 
        IFNULL(imgs, '[]') AS imgs 
      FROM topic 
      ORDER BY id DESC
    `);

    // 把 imgs JSON 字符串解析成数组
    const topics = rows.map(r => {
      let arr;
      try {
        arr = JSON.parse(r.imgs);
      } catch {
        arr = [];
      }
      return {
        id: r.id,
        title: r.title,
        content: r.content,
        imgs: arr
      };
    });

    res.json({
      code: 0,
      message: '查询成功',
      data: topics
    });
  } catch (err) {
    handleDatabaseError(res, err);
  }
});



// 启动服务器
const port = 3000;
app.listen(port, () => {
  console.log(`服务器运行在 http://127.0.0.1:${port}`);
});
